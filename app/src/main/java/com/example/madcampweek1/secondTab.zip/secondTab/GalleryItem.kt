package com.example.madcampweek1.secondTab

import android.net.Uri

data class GalleryItem(val imageResource: Uri, val title: String)
